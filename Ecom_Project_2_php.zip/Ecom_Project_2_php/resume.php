<?php
// Project Start le  14-11-2024
// Ecom Project 128 v  php Mysql jquery bootstrap

// v 90
// ini_set("display_errors","on");
// error_reporting(E_ALL);



// V 76
/*ALTER TABLE comments  add CONSTRAINT fr_Cmnt_Item 
FOREIGN key(Item_id_cmnt) REFERENCES items (ItemID ) 
on DELETE CASCADE 
on UPDATE CASCADE 

ALTER TABLE comments add CONSTRAINT fk_User_comnt 
FOREIGN KEY(User_id_cmnt ) REFERENCES users(UserID) 
on DELETE CASCADE on UPDATE CASCADE */




// V11 login user


// V10 connecte db base de donnees

// V9  cration base de donnees


// V8  Langague File






// V7 php init
// pour les chemain css et js
